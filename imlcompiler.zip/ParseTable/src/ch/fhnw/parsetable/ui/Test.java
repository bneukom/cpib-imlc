package ch.fhnw.parsetable.ui;

public class Test {
	public static void main(String[] args) {
		System.out.println("oink");
	}

	private static void doShit() {
		System.out.println("SHIT");
	}
}
