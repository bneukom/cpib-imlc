package ch.fhnw.imlcompiler;

public class Jimlc {
	public static void main(String[] args) {
		Imlc.main(args);
	}
}